Dynamic link library libxxx. So file name format:
Lib and.so prefix and suffix: standard dynamic link library format
Hps3d: dynamically linked library name, consistent with device name
32/64: indicates that the dynamic link library is 32-bit or 64-bit
176: represents the version number of the dynamically linked library
