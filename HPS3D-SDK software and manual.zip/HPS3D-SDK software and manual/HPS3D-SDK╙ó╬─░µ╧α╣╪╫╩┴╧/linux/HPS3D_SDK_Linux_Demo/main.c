/**********************************************************************
* COPYRIGHT NOTICE - HYPERSEN TECHNOLOGY
*
* Copyright (c) 2018, Hypersen Technology, Inc.
*
* All rights reserved.
*
*======================================================================
* \file main.c
* \brief TODO
* \author Kevin
* \email Kevin_Wang@hypersen.com
* \version 1.0.0
* \date 2018年12月5日 下午5:06:03
* \license private & classified
*---------------------------------------------------------------------
* Remark: This project is still under construction.
*======================================================================
* Change History:
*---------------------------------------------------------------------
* <Date>			| <Version>	| <Author>			| <Description>
*---------------------------------------------------------------------
* 2018年12月5日			| V1.0.0	| Kevin				| Create file
*======================================================================
* Detailed Notes:
*---------------------------------------------------------------------
* <Version>		| <Description>
*---------------------------------------------------------------------
* V1.0.0		| TODO
*---------------------------------------------------------------------

**********************************************************************/
#include <stdio.h>
#include <string.h>
#include <signal.h>
#include "api.h"
#include <unistd.h>
#include <stdlib.h>
HPS3D_HandleTypeDef handle;
AsyncIObserver_t My_Observer;
ObstacleConfigTypedef ObstacleConf;

/*
 * User processing function,Continuous measurement or asynchronous mode
 * in which the observer notifies the callback function
 * */
void* User_Func(HPS3D_HandleTypeDef *handle,AsyncIObserver_t *event)
{
	int indx = 0;
	if(event->AsyncEvent == ISubject_Event_DataRecvd)
	{
		switch(event->RetPacketType)
		{
			case SIMPLE_ROI_PACKET:
				printf("distance average:%d\n",event->MeasureData.simple_roi_data[0].distance_average);
				break;
			case FULL_ROI_PACKET:
				printf("distance average:%d\n",event->MeasureData.full_roi_data[0].distance_average);
				break;
			case FULL_DEPTH_PACKET:
				printf("distance average:%d\n",event->MeasureData.full_depth_data->distance_average);
				break;
			case SIMPLE_DEPTH_PACKET:
				printf("distance average:%d\n",event->MeasureData.simple_depth_data->distance_average);
				break;
			case OBSTACLE_PACKET:
				break;
			case NULL_PACKET:
				break;
			default:
				printf("system error\n");
				break;
		}
	}
}


void signal_handler(int signo)
{
	HPS3D_RemoveObserver(&My_Observer);
	HPS3D_RemoveDevice(&handle);
    exit(0);
}

/*
 * Debugging use
 * */
void User_Printf(uint8_t *str)
{
	printf("%s\n",str);
}


int main()
{
	uint8_t fileName[DEV_NUM][DEV_NAME_SIZE] = {0};
	uint32_t i=0;
	uint32_t n = 0;
	uint32_t a = 0;
	int indx = 0;
	RET_StatusTypeDef ret = RET_OK;

	HPS3D_SetDebugEnable(true);
	HPS3D_SetDebugFunc(&User_Printf);

	/*Observer initialization*/
	My_Observer.AsyncEvent = ISubject_Event_DataRecvd;
	My_Observer.NotifyEnable = true;
	My_Observer.ObserverID = 2;
	My_Observer.RetPacketType = NULL_PACKET;


	n = HPS3D_GetDeviceList("/dev/","ttyACM",fileName);
	printf("Please select the device to connect：\n");
	for(int i=0;i<n;i++)
	{
		printf("%d: %s\n",i,fileName[i]);
	}
	printf("Enter the serial number：\n");
	scanf("%d",&a);
	handle.DeviceName = fileName[a];
	if(signal(SIGINT,signal_handler) == SIG_ERR)
	{
		printf("sigint error");
	}
	do
	{
		ret = HPS3D_Connect(&handle);
		if(ret != RET_OK)
		{
			printf("Connect Failed！ret = %d\n",ret);
			break;
		}

		HPS3D_SetPointCloudEn(true);
		/*Obstacle parameter configuration initialization*/
		ObstacleConf.enable = false;
		ObstacleConf.frame_head = 0xEB81;
		ObstacleConf.invaild_value = 15000;
		ObstacleConf.number = 3;
		ObstacleConf.vaild_max_dist = 5000;
		ObstacleConf.vaild_min_dist = 200;
		HPS3D_ObstacleConfigInit(&ObstacleConf);

		/*Device initialization*/
		ret = HPS3D_ConfigInit(&handle);
		if(RET_OK != ret)
		{
			printf("Initialization failed! error code is:%d\n", ret);
			break;
		}
		printf("Initialization succeed!\n");

#if 1
		/*Adding asynchronous observers,Only valid in asynchronous or continuous measurement mode*/
		HPS3D_AddObserver(&User_Func,&handle,&My_Observer);
		/*Set to continuous measurement mode*/
		handle.RunMode = RUN_CONTINUOUS;
		HPS3D_SetRunMode(&handle);
#endif
	}while(0);

	if(ret != RET_OK)
	{
		HPS3D_RemoveDevice(&handle);
	    return -1;
	}

	while(1)
	{
#if 0
		/*Synchronous single measurement mode*/
		ret = HPS3D_SingleMeasurement(&handle);
		indx = 0;
		if(ret == RET_OK)
		{
			switch(handle.RetPacketType)
			{
				case SIMPLE_ROI_PACKET:
					printf("Simple roi measure distance average:%d \n",handle.MeasureData.simple_roi_data[0].distance_average);
					break;
				case FULL_ROI_PACKET:
					printf("Full roi measure distance average:%d \n",handle.MeasureData.full_roi_data[0].distance_average);
					break;
				case FULL_DEPTH_PACKET:
					printf("Full depth measure distance average:%d \n",handle.MeasureData.full_depth_data->distance_average);
					break;
				case SIMPLE_DEPTH_PACKET:
					printf("Simple depth measure distance average:%d \n",handle.MeasureData.simple_depth_data->distance_average);
					break;
				case OBSTACLE_PACKET:
					break;
				case NULL_PACKET:
					printf("Return packet is null\n");
					break;
				default:
					printf("system error\n");
					break;
			}
		}
#endif
	}

	/*Remove the device and Observer*/
	HPS3D_RemoveObserver(&My_Observer);
	HPS3D_RemoveDevice(&handle);

	return 0;
}


